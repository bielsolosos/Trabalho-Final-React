package br.com.serratec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoFinalGrupo4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
