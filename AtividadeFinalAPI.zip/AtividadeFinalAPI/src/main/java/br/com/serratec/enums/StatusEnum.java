package br.com.serratec.enums;

public enum StatusEnum {
	
	ENTREGUE,PENDENTE,PAGO,CANCELADO,ENVIADO;


}
