package br.com.serratec.enums;

public enum EstadoEnum {

	RJ,SP,MG;
}
