# AtividadeFinalAPI

<h1>INTEGRANTES:</h1>
<ul>
  <li>José Fernando Pereira</li>
  <li>Guido Scagliusi</li>
  <li>Carlos Alberto</li>
  <li>Eduardo Almeida</li>
  <li>Marcela Andriolo</li>
  <li>Gustavo Dantas</li>
</ul>
